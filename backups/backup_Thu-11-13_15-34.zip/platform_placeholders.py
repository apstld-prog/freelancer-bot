# Placeholder platform scrapers (disabled by default).
# Clean UTF-8, no BOM, no broken characters.

def search_placeholder(keyword: str):
    return []


