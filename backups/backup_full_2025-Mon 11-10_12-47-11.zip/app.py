# Minimal wrapper for Render / Uvicorn compatibility
from server import app

# Nothing else needed here
